export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyB8sv35xR6YwcZ5e5zPeioaxMU3tp5dfb4",
    authDomain: "appregistrr.firebaseapp.com",
    projectId: "appregistrr",
    storageBucket: "appregistrr.appspot.com",
    messagingSenderId: "7350694014",
    appId: "1:7350694014:web:047a6308f161e5cbb6282f",
    measurementId: "G-VVBGHHJ5QV"
  }
};
