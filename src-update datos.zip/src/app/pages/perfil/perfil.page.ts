import { Component, OnInit } from '@angular/core';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-perfil',
  templateUrl: './perfil.page.html',
  styleUrls: ['./perfil.page.scss'],
})
export class PerfilPage implements OnInit {
  
  nombreEstudiante = this.user.getEstudianteActual().displayName;
  correoEstudiante = this.user.getEstudianteActual().email;
  edadEstudiante = 20;
  carreraEstudiante = 'Ingeniería Informática';
   
  constructor(private user: UsersService) {
    
  }

  ngOnInit() {
  }

}
