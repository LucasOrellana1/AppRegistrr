export interface RespuestaTopHeadlines {
    nombre: string;
    fecha: Date;
    irrenunciable: boolean;
    tipo: string;
}